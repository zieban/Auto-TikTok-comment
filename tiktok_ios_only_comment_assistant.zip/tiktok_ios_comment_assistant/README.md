# iOS-only TikTok Comment Assistant

This version is designed to be used entirely from an iPhone/iPad browser.

It does NOT automate TikTok itself. Safari cannot programmatically control the TikTok app or another website's page. Instead, this app lets you keep a queue of TikTok video links, record like counts, filter under-10-like videos, prepare comments, copy them, open TikTok, and mark videos as posted/skipped.

## Use on iPhone

The simplest option is to host this folder on a static web host.

Then open the site's URL in Safari.

For an iPhone-only setup, use a static hosting service such as GitHub Pages:

1. Create a GitHub repository.
2. Upload `index.html`, `manifest.webmanifest`, `icon.svg`, and the `static` folder.
3. In GitHub, open Settings → Pages.
4. Select the branch/folder containing the files.
5. Open the generated Pages URL on your iPhone.

You do not need Python for this version.

## iPhone workflow

1. Open TikTok.
2. Find a video.
3. Tap Share → Copy link.
4. Return to this web app.
5. Paste the link and tap Add video.
6. Enter the visible like count.
7. The Under 10 filter lets you find qualifying videos.
8. Write a comment.
9. Tap Copy comment.
10. Open the TikTok video.
11. Paste the comment and submit it yourself in TikTok.
12. Return to the assistant and tap Mark as posted.

## Add to Home Screen

In Safari, tap Share → Add to Home Screen.

The app stores its queue and comments locally using browser storage.

## Important

This is an iOS-only assisted workflow. It intentionally does not automate TikTok posting, bypass CAPTCHAs, evade anti-bot systems, or mass-submit comments.
