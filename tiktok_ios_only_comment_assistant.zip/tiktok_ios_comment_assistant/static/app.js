const KEY="tca_ios_v1";
let db=JSON.parse(localStorage.getItem(KEY)||'{"videos":[],"presets":["Nice one!","This is actually so good.","Clean.","Love this."]}');
let currentId=null, filter="all";

const $=id=>document.getElementById(id);
function save(){localStorage.setItem(KEY,JSON.stringify(db));render();}
function current(){return db.videos.find(v=>v.id===currentId);}
function status(v){return v.posted?"posted":v.skipped?"skipped":"pending";}
function render(){
  const v=current();
  $("empty").hidden=!!v; $("current").hidden=!v;
  if(v){
    $("currentUrl").textContent=v.url;
    $("likes").value=v.likes??"";
    $("comment").value=v.comment||"";
  }
  let list=db.videos.filter(v=>{
    if(filter==="under10") return Number.isFinite(v.likes)&&v.likes<10;
    if(filter==="pending") return status(v)==="pending";
    return true;
  });
  $("queue").innerHTML=list.length?list.map(v=>`
    <button class="row" data-id="${v.id}">
      <span>${Number.isFinite(v.likes)?v.likes+" likes":"likes unknown"}</span>
      <b>${status(v)}</b>
    </button>`).join(""):"<p class='hint'>No videos here.</p>";
  document.querySelectorAll(".row").forEach(x=>x.onclick=()=>{
    currentId=x.dataset.id; render();
    window.scrollTo({top:document.body.scrollHeight/3,behavior:"smooth"});
  });
  $("presets").innerHTML=db.presets.map((p,i)=>
    `<button class="preset" data-i="${i}">${escapeHtml(p)}</button>`).join("");
  document.querySelectorAll(".preset").forEach(x=>x.onclick=()=>{
    const v=current(); if(!v)return;
    $("comment").value=db.presets[Number(x.dataset.i)]; v.comment=$("comment").value; save();
  });
}
function escapeHtml(s){return s.replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));}

$("add").onclick=()=>{
  const url=$("url").value.trim();
  if(!url){alert("Paste a TikTok video URL first.");return;}
  if(!url.includes("tiktok.com")){alert("That does not look like a TikTok URL.");return;}
  const existing=db.videos.find(v=>v.url===url);
  if(existing) currentId=existing.id;
  else{
    const v={id:crypto.randomUUID(),url,likes:null,comment:"",posted:false,skipped:false,created:Date.now()};
    db.videos.unshift(v); currentId=v.id;
  }
  $("url").value=""; save();
};
$("likes").oninput=()=>{const v=current();if(!v)return;v.likes=$("likes").value===""?null:Number($("likes").value);save()};
$("comment").oninput=()=>{const v=current();if(v){v.comment=$("comment").value;localStorage.setItem(KEY,JSON.stringify(db))}};
$("copy").onclick=async()=>{
  const v=current();if(!v)return;
  if(!v.comment.trim()){alert("Enter a comment first.");return}
  await navigator.clipboard.writeText(v.comment.trim());
  alert("Comment copied. Open TikTok and paste it into the comment box.");
};
$("openCurrent").onclick=()=>{const v=current();if(v)location.href=v.url};
$("openTikTok").onclick=()=>location.href="https://www.tiktok.com/";
$("posted").onclick=()=>{const v=current();if(v){v.posted=true;v.skipped=false;save()}};
$("skip").onclick=()=>{const v=current();if(v){v.skipped=true;v.posted=false;save()}};
$("under10").onclick=()=>{const v=current();if(v){v.likes=9;$("likes").value=9;save()}};
document.querySelectorAll(".filter").forEach(x=>x.onclick=()=>{
  filter=x.dataset.filter;
  document.querySelectorAll(".filter").forEach(b=>b.classList.toggle("active",b===x));
  render();
});
$("savePreset").onclick=()=>{
  const x=$("presetInput").value.trim();if(!x)return;
  db.presets.push(x);$("presetInput").value="";save();
};
$("clear").onclick=()=>{
  if(confirm("Delete all locally stored videos and comments?")){
    db={videos:[],presets:[]};currentId=null;save();
  }
};
render();
